ATM Withdrawal Flowchart - Tuwaiq Academy

1. Open index.html in any browser to see the website (it works on phones too).
2. ATM-Withdrawal-Flowchart.pdf is the PDF version. The last slide of the website has a button that downloads it.
3. Keep both files in the same folder.
